# CFS (CAPITAL FINANCE SOLUTIONS) Clone Project Todos

## Phase 1: Core Site Structure & Homepage

### Core Structure & Global Elements
- [x] **Project Setup:** Initialize `nextjs-shadcn` project (DONE - project name `xm-clone` kept for file system, internal references updated where possible)
- [x] **Dependency Installation:** (DONE)
- [x] **Global Styles:**
    - [x] Setup "Inter" font family (DONE)
    - [x/] Define primary color palette in Tailwind CSS config (DONE - using XM's initial palette, can be refined for CFS)
- [ ] **Global Navbar:** (IN PROGRESS)
    - [x] Logo (Placeholder, alt text updated to CFS)
    - [x] Navigation links (Home, Services (Loans, Trading, Investments dropdown), About Us, Blog, Contact Us, Partner with Us) - *Updated with dropdown*
    - [x] "Login" button
    - [x] "Get Started" button
    - [ ] Mobile responsiveness for Navbar
- [ ] **Global Footer:**
    - [ ] CFS Copyright, contact info, social links
    - [ ] Links: Privacy Policy, Terms & Conditions
    - [ ] Disclaimer about financial services

### Homepage (Content based on CFS Description)
- [ ] **Hero Section:** (IN PROGRESS)
    - [x] Main headline: "CAPITAL FINANCE SOLUTIONS"
    - [x] Sub-headline: Briefly explain core offerings (Loans, Investments, Trading).
    - [x] Primary Call-to-Action (e.g., "Explore Our Solutions" or "Get Started")
    - [ ] Professional background imagery suitable for finance.
- [ ] **Services Overview Section:** (IN PROGRESS)
    - [ ] Title (e.g., "Our Financial Services")
    - [ ] **Loans Subsection:**
        - [ ] Brief intro to CFS loan services.
        - [ ] Cards/icons for Personal, Business, Automobile loans.
        - [ ] Link to a dedicated Loans page.
    - [ ] **Investing & Trading Subsection:**
        - [ ] Brief intro to CFS investment/trading platform.
        - [ ] Cards/icons for Stocks, Mutual Funds, IPOs, Online Trading.
        - [ ] Link to a dedicated Trading/Investments page.
    - [ ] **Funding Solutions Subsection:** (How CFS gets funds)
        - [ ] Brief intro to how CFS is funded.
        - [ ] Information about partnering with Banks, attracting Investors, and Crowdfunding.
        - [ ] Calls to action for potential investors or crowdfunding participants.
- [ ] **"Why Choose CFS?" Section:** (Trust builders)
    - [ ] Key benefits of using CFS.
    - [ ] Security, expertise, customer support highlights.
- [ ] **Call to Action Section:** (e.g., Open an Account, Apply for a Loan)

## Phase 2: Detailed Service Pages (UI Only)

- [ ] **Loans Pages:**
    - [ ] Main Loans landing page (overview of all loan types)
    - [ ] Individual Page: Personal Loans (details, benefits, inquiry form UI)
    - [ ] Individual Page: Business Loans (details, benefits, inquiry form UI)
    - [ ] Individual Page: Automobile Loans (details, benefits, inquiry form UI)
- [ ] **Investing & Trading Pages:**
    - [ ] Main Investing/Trading landing page
    - [ ] Page: Stocks (info, mock charts, buy/sell UI)
    - [ ] Page: Mutual Funds (info, fund listings UI)
    - [ ] Page: IPOs (info, upcoming IPOs UI)
    - [ ] Page: Online Trading Platform (mock trading dashboard UI)
- [ ] **Funding Pages:**
    - [ ] Page: For Investors (how to invest in CFS, benefits, contact UI)
    - [ ] Page: Crowdfunding (how to participate, current projects UI)
- [ ] **Standard Pages:**
    - [ ] About Us (Company mission, team, values)
    - [ ] Contact Us (Contact form, map, address, phone)
    - [ ] Blog (Listing page, individual article page structure)
    - [ ] FAQ

## Phase 3: Enhancements & Refinements
- [ ] Detailed styling and branding for CFS (colors, typography)
- [ ] Advanced UI elements and interactivity
- [ ] Comprehensive responsiveness review
- [ ] Accessibility review

## Cross-cutting Concerns
- [x] **Responsiveness:** Ensure all cloned pages and sections are responsive (Ongoing)
- [ ] **Accessibility:** Basic accessibility considerations (Ongoing)
- [ ] **Asset Management:** Organize and optimize images and other assets (Ongoing)

**Note:** Backend functionality (user accounts, loan processing, trading, etc.) is out of scope. This focuses on UI/UX creation based on the CFS description.
