import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import React from 'react';
import { cn } from "@/lib/utils";

interface NavItem {
  href: string;
  label: string;
  subItems?: NavItem[];
}

const Navbar = () => {
  const navLinks: NavItem[] = [
    { href: '/', label: 'Home' },
    {
      href: '/services',
      label: 'Services',
      subItems: [
        { href: '/services/loans', label: 'Loans' },
        { href: '/services/trading', label: 'Trading' },
        { href: '/services/investments', label: 'Investments' },
      ],
    },
    { href: '/about-us', label: 'About Us' },
    { href: '/blog', label: 'Blog' },
    { href: '/contact-us', label: 'Contact Us' },
    { href: '/partner-with-us', label: 'Partner with Us' },
  ];

  return (
    <nav className="bg-xm-dark-blue text-xm-light-gray p-4 flex items-center justify-between">
      {/* Logo */}
      <div className="flex items-center">
        <Link href="/" className="mr-10">
          <Image src="https://ext.same-assets.com/3161908157/548389142.svg" alt="CFS Logo" width={100} height={24} />
        </Link>
      </div>

      {/* Navigation Links */}
      <NavigationMenu className="hidden md:flex flex-grow justify-center">
        <NavigationMenuList>
          {navLinks.map((link) =>
            link.subItems ? (
              <NavigationMenuItem key={link.label}>
                <NavigationMenuTrigger className="bg-xm-dark-blue hover:text-xm-gold focus:text-xm-gold data-[active]:text-xm-gold data-[state=open]:text-xm-gold">
                  {link.label}
                </NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[400px] gap-3 p-4 md:w-[200px] bg-xm-dark-blue text-xm-light-gray">
                    {link.subItems.map((subItem) => (
                      <ListItem
                        key={subItem.label}
                        title={subItem.label}
                        href={subItem.href}
                      />
                    ))}
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>
            ) : (
              <NavigationMenuItem key={link.label}>
                <Link href={link.href} legacyBehavior passHref>
                  <NavigationMenuLink className={cn(navigationMenuTriggerStyle(), "bg-xm-dark-blue hover:text-xm-gold focus:text-xm-gold data-[active]:text-xm-gold")}>
                    {link.label}
                  </NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
            )
          )}
        </NavigationMenuList>
      </NavigationMenu>

      {/* Action Buttons */}
      <div className="flex items-center space-x-3">
        <Button variant="outline" className="border-xm-light-gray text-xm-light-gray hover:bg-xm-gray hover:text-xm-light-gray">
          Login
        </Button>
        <Button className="bg-xm-gold text-xm-dark-blue hover:bg-opacity-80">
          Get Started
        </Button>
        {/* TODO: Add a Mobile Menu Button for smaller screens */}
      </div>
    </nav>
  );
};

const ListItem = React.forwardRef<
  React.ElementRef<"a">,
  React.ComponentPropsWithoutRef<"a">
>(({ className, title, children, ...props }, ref) => {
  return (
    <li>
      <NavigationMenuLink asChild>
        <a
          ref={ref}
          className={cn(
            "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-xm-gray hover:text-xm-gold focus:bg-xm-gray focus:text-xm-gold",
            className
          )}
          {...props}
        >
          <div className="text-sm font-medium leading-none">{title}</div>
          {children && <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">{children}</p>}
        </a>
      </NavigationMenuLink>
    </li>
  );
});
ListItem.displayName = "ListItem";

export default Navbar;
