import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Landmark, Users, Briefcase, Car,
  LineChart, TrendingUp, Target, PiggyBank, Building, Handshake
} from "lucide-react";
import Link from "next/link";

export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen">
      {/* Hero Section */}
      <section
        id="hero"
        className="w-full py-20 md:py-32 lg:py-40 bg-xm-dark-blue text-center text-xm-light-gray"
      >
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            CAPITAL FINANCE SOLUTIONS
          </h1>
          <p className="text-lg md:text-xl lg:text-2xl mb-8 max-w-3xl mx-auto">
            Your trusted partner for comprehensive loan services, strategic investments, and dynamic online trading.
          </p>
          <Button size="lg" className="bg-xm-gold text-xm-dark-blue hover:bg-opacity-80 text-lg px-8 py-3">
            Explore Our Solutions
          </Button>
        </div>
      </section>

      {/* Services Overview Section */}
      <section id="services-overview" className="w-full py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-16 text-center text-xm-dark-blue">Our Financial Solutions</h2>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Loans Subsection Card */}
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-center mb-4 w-16 h-16 bg-xm-teal text-white rounded-full mx-auto">
                  <Landmark size={32} />
                </div>
                <CardTitle className="text-2xl font-semibold text-center text-xm-dark-blue">Loans Tailored For You</CardTitle>
              </CardHeader>
              <CardContent className="text-center text-xm-gray">
                <p className="mb-6">Access flexible and competitive financing for your personal ambitions, business growth, or next vehicle purchase.</p>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center justify-center space-x-2 text-sm">
                    <Users size={18} className="text-xm-teal"/><span>Personal Loans</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm">
                    <Briefcase size={18} className="text-xm-teal"/><span>Business Loans</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm">
                    <Car size={18} className="text-xm-teal"/><span>Automobile Loans</span>
                  </div>
                </div>
                <Button asChild variant="link" className="text-xm-teal hover:text-xm-gold">
                  <Link href="/services/loans">Learn More About Loans &rarr;</Link>
                </Button>
              </CardContent>
            </Card>

            {/* Investing & Trading Subsection Card */}
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-center mb-4 w-16 h-16 bg-xm-gold text-white rounded-full mx-auto">
                  <LineChart size={32} />
                </div>
                <CardTitle className="text-2xl font-semibold text-center text-xm-dark-blue">Invest & Trade with Confidence</CardTitle>
              </CardHeader>
              <CardContent className="text-center text-xm-gray">
                <p className="mb-6">Navigate the markets with our robust platform, offering access to stocks, mutual funds, IPOs, and advanced trading tools.</p>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center justify-center space-x-2 text-sm">
                    <TrendingUp size={18} className="text-xm-gold"/><span>Online Trading</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm">
                    <Briefcase size={18} className="text-xm-gold"/><span>Stocks & IPOs</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm">
                    <Target size={18} className="text-xm-gold"/><span>Mutual Funds</span>
                  </div>
                </div>
                <Button asChild variant="link" className="text-xm-gold hover:text-xm-teal">
                  <Link href="/services/investments">Explore Investment Options &rarr;</Link>
                </Button>
              </CardContent>
            </Card>

            {/* Funding Solutions Subsection Card */}
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-center mb-4 w-16 h-16 bg-xm-steel-blue text-white rounded-full mx-auto">
                  <Handshake size={32} />
                </div>
                <CardTitle className="text-2xl font-semibold text-center text-xm-dark-blue">Innovative Funding Partnerships</CardTitle>
              </CardHeader>
              <CardContent className="text-center text-xm-gray">
                <p className="mb-6">CFS thrives by collaborating with diverse funding sources. Explore opportunities for banks, investors, and crowdfunding participants.</p>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center justify-center space-x-2 text-sm">
                    <Building size={18} className="text-xm-steel-blue"/><span>Bank Collaborations</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm">
                    <Users size={18} className="text-xm-steel-blue"/><span>Investor Relations</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm">
                    <PiggyBank size={18} className="text-xm-steel-blue"/><span>Crowdfunding Platforms</span>
                  </div>
                </div>
                <Button asChild variant="link" className="text-xm-steel-blue hover:text-xm-gold">
                  <Link href="/partner-with-us">Partner with CFS &rarr;</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Why Choose CFS? Section - Placeholder */}
      <section id="why-choose-cfs" className="w-full py-16 md:py-24 bg-xm-light-gray">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-xm-dark-blue">Why Choose CFS?</h2>
          <p className="text-xm-gray">Information about our expertise, security, and customer focus will be here.</p>
        </div>
      </section>

      {/* CTA Section - Placeholder */}
      <section id="cta" className="w-full py-20 md:py-32 bg-xm-dark-blue text-center text-xm-light-gray">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to achieve your financial goals?</h2>
          <Button size="lg" className="bg-xm-gold text-xm-dark-blue hover:bg-opacity-80 text-lg px-8 py-3 mr-4">
            Open an Account
          </Button>
          <Button size="lg" variant="outline" className="border-xm-gold text-xm-gold hover:bg-xm-gold hover:text-xm-dark-blue text-lg px-8 py-3">
            Apply for a Loan
          </Button>
        </div>
      </section>
    </main>
  );
}
