import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import ClientBody from "./ClientBody";
import Navbar from '@/components/layout/navbar'; // Import Navbar

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

export const metadata: Metadata = {
  title: "CFS Clone", // Updated title
  description: "A clone of the CFS.com website", // Updated description
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${inter.variable}`}>
      <body suppressHydrationWarning className="antialiased font-sans bg-xm-light-gray">
        <ClientBody>
          <Navbar />
          {children}
          {/* TODO: Add Footer here later */}
        </ClientBody>
      </body>
    </html>
  );
}
